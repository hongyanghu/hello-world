package com.example.service;

import org.junit.Test;

import static org.junit.Assert.assertEquals;



    public class CalculatorServiceTest {
        private CalculatorService calculatorService = new CalculatorService();

        @Test
        public void testAddition() {
            assertEquals("普通加法运算失败", 5.0, calculatorService.calculate("2+3"), 0.001);
        }

        @Test
        public void testSubtraction() {
            assertEquals("普通减法运算失败", 1.0, calculatorService.calculate("3-2"), 0.001);
        }

        @Test
        public void testMultiplication() {
            assertEquals("普通乘法运算失败", 6.0, calculatorService.calculate("2*3"), 0.001);
        }

        @Test
        public void testDivision() {
            assertEquals("普通除法运算失败", 2.0, calculatorService.calculate("6/3"), 0.001);
        }

        @Test
        public void testComplexExpression() {
            assertEquals("复杂表达式运算失败", 7.0, calculatorService.calculate("(2+3)*1.4"), 0.001);
        }

    }

