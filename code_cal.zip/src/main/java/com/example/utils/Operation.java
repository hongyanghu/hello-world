package com.example.utils;

public interface Operation {
    double apply(double a, double b);
}



