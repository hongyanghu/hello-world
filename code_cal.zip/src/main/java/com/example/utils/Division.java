package com.example.utils;

public class Division implements Operation {
    @Override
    public double apply(double a, double b) {
        return a / b;
    }
}
