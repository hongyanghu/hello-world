package com.example.service;


import com.example.mapper.HistoryMapper;
import com.example.model.Calculation;

import com.example.utils.OperationFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Stack;

@Service
public class CalculatorService {

    @Autowired
    private HistoryMapper historyMapper;


    private Stack<Double> values = new Stack<>();
    private Stack<Character> operators = new Stack<>();
    private Stack<Double> undoStack = new Stack<>();
    private Stack<Double> redoStack = new Stack<>();

    /**
     * 应用给定的运算符在值栈的顶部两个元素上。
     *
     * @param operator 要应用的运算符。
     * @author huhongyang
     */
    private void applyOperation(char operator) {
        double b = values.pop();
        double a = values.pop();
        values.push(OperationFactory.getOperation(operator).apply(a, b));
    }

    /**
     * 计算给定算术表达式的结果。
     * 表达式应该是一个有效的中缀表达式，包含单个数字，并可能包含括号。
     *
     * @param expression 要计算的算术表达式。
     * @return 表达式的计算结果。
     * @author huhongyang
     */
    public double calculate(String expression) {
        // 将中缀表达式转换为后缀表达式
        String postfix = infixToPostfix(expression);
        // 计算后缀表达式的值
        return evaluatePostfix(postfix);
    }
    /**
     * 将中缀算术表达式转换为后缀（逆波兰表示法）表达式。
     * 该方法假设中缀表达式具有有效的语法。
     *
     * @param expression 要转换的中缀算术表达式。
     * @return 转换后的后缀表达式。
     * @author huhongyang
     */
    private String infixToPostfix(String expression) {
        StringBuilder result = new StringBuilder();
        Stack<Character> stack = new Stack<>();

        for (int i = 0; i < expression.length(); i++) {
            char c = expression.charAt(i);

            // 如果是数字，直接加入结果字符串
            if (Character.isDigit(c)) {
                result.append(c);
            } else if (c == '(') {
                stack.push(c);
            } else if (c == ')') {
                while (!stack.isEmpty() && stack.peek() != '(') {
                    result.append(stack.pop());
                }
                stack.pop();
            } else {
                while (!stack.isEmpty() && getPrecedence(c) <= getPrecedence(stack.peek())) {
                    result.append(stack.pop());
                }
                stack.push(c);
            }
        }

        while (!stack.isEmpty()) {
            if (stack.peek() == '(') {
                return "Invalid Expression";
            }
            result.append(stack.pop());
        }

        return result.toString();
    }

    /**
     * 返回给定算术运算符的优先级。
     * 返回值较高表示优先级较高。
     *
     * @param ch 运算符字符。
     * @return 运算符的优先级。
     * @author huhongyang
     */
    private int getPrecedence(char ch) {
        switch (ch) {
            case '+':
            case '-':
                return 1;
            case '*':
            case '/':
                return 2;
        }
        return -1;
    }


    /**
     * 计算给定的后缀（逆波兰表示法）表达式并返回结果。
     * 表达式应该是一个有效的后缀表达式，包含单个数字。
     *
     * @param postfix 要评估的后缀算术表达式。
     * @return 评估的后缀表达式的结果。
     * @author huhongyang
     */
    private double evaluatePostfix(String postfix) {
        Stack<Double> stack = new Stack<>();

        for (int i = 0; i < postfix.length(); i++) {
            char c = postfix.charAt(i);

            if (Character.isDigit(c)) {
                stack.push((double) (c - '0'));
            } else {
                double b = stack.pop();
                double a = stack.pop();
                switch (c) {
                    case '+':
                        stack.push(a + b);
                        break;
                    case '-':
                        stack.push(a - b);
                        break;
                    case '*':
                        stack.push(a * b);
                        break;
                    case '/':
                        if (b == 0)
                            throw new UnsupportedOperationException("Cannot divide by zero");
                        stack.push(a / b);
                        break;
                }
            }
        }

        return stack.pop();
    }

    /**
     * 执行撤销操作，返回上一次的计算结果。
     *
     * @return 上一次的计算结果。
     * @throws IllegalStateException 如果没有可撤销的操作时抛出。
     * @author huhongyang
     */
    public double undo() {
        if (!undoStack.isEmpty()) {
            double lastValue = undoStack.pop();
            redoStack.push(lastValue);
            return lastValue;
        }
        throw new IllegalStateException("No more operations to undo");
    }

    /**
     * 执行重做操作，返回重做后的计算结果。
     *
     * @return 重做后的计算结果。
     * @throws IllegalStateException 如果没有可重做的操作时抛出。
     * @author huhongyang
     */
    public double redo() {
        if (!redoStack.isEmpty()) {
            double lastValue = redoStack.pop();
            undoStack.push(lastValue);
            return lastValue;
        }
        throw new IllegalStateException("No more operations to redo");
    }

    /**
     * 保存当前的计算结果。
     *
     * @param expression 表达式。
     * @param result 结果
     * @throws IllegalArgumentException 如果计算结果无效时抛出。
     * @author huhongyang
     */
    public void saveCalculation(String expression, String result) {
        Calculation calculation = new Calculation();
        calculation.setExpression(expression);
        calculation.setResult(result);
        // Set createdAt to current time
        historyMapper.insertCalculation(calculation);
    }

    /**
     * 获取计算历史记录。
     *
     * @return 计算历史的列表。
     * @throws IllegalStateException 如果无法获取计算历史时抛出。
     * @author huhongyang
     */
    public List<Calculation> getCalculationHistory() {
        return historyMapper.findAllCalculations();
    }
}
