package com.example.controller;


import com.example.model.Calculation;
import com.example.service.CalculatorService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/calculator")
public class CalculatorController {

    @Autowired
    private CalculatorService calculatorService;

    @GetMapping("/calculate")
    public ResponseEntity<String> calculate(@RequestParam String expression) {
        try {
            double result = calculatorService.calculate(expression);
            return ResponseEntity.ok(String.valueOf(result));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body("Error");
        }
    }

    @GetMapping("/history")
    public List<Calculation> getHistory() {
        return calculatorService.getCalculationHistory();
    }
}
