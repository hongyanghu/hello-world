package com.example.model;





import java.util.Date;

public class Calculation {
    private Long id;
    private String expression;
    private String result;
    private Date createdAt;

    // Getters and setters
    // ...

    public String getExpression() {
        return expression;
    }

    public void setExpression(String expression) {
        this.expression = expression;
    }

    public String getResult() {
        return result;
    }

    public void setResult(String result) {
        this.result = result;
    }

    public Date getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Date createdAt) {
        this.createdAt = createdAt;
    }
}



