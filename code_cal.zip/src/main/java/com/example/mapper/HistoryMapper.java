package com.example.mapper;



import com.example.model.Calculation;

import java.util.List;

public interface HistoryMapper {
    void insertCalculation(Calculation calculation);
    List<Calculation> findAllCalculations();
}

