document.addEventListener("DOMContentLoaded", function() {
    // Function to append value to the expression input
    function appendToExpression(value) {
        const expressionInput = document.getElementById("expressionInput");
        expressionInput.value += value;
    }

    // Function to clear the expression input
    function clearExpression() {
        const expressionInput = document.getElementById("expressionInput");
        expressionInput.value = "";
    }

    // Function to calculate the expression using the backend API
    function calculateExpression() {
        const expressionInput = document.getElementById("expressionInput");
        const expression = expressionInput.value;

        fetch("/calculator/calculate?expression=" + encodeURIComponent(expression))
            .then(response => response.text())
            .then(result => {
                expressionInput.value = result;

                // Append the calculation to the history
                const historyList = document.getElementById("historyList");
                const listItem = document.createElement("li");
                listItem.textContent = expression + " = " + result;
                historyList.appendChild(listItem);
            })
            .catch(error => {
                console.error("Error:", error);
            });
    }

    // Attach click event handlers to buttons
    const buttons = document.querySelectorAll("button");
    buttons.forEach(button => {
        button.addEventListener("click", function() {
            const value = button.textContent;
            if (value === "=") {
                calculateExpression();
            } else if (value === "C") {
                clearExpression();
            } else {
                appendToExpression(value);
            }
        });
    });
});
